package com.example.lab2android;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    String description = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* LAB 1 */

        final ListView productsList = (ListView) findViewById(R.id.productsList);
        final TextView bookDescription = (TextView) findViewById(R.id.bookDescription);

        String[] bookTitles = new String[]{
                "Life of Pi",
                "Crime and Punishment",
                "The Karamazov Brothers",
                "War and Peace"
        };

        ArrayList<String> products = new ArrayList<>(Arrays.asList(bookTitles));

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, products);

        productsList.setAdapter(arrayAdapter);
        productsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedTitle = (String) productsList.getItemAtPosition(position);
                String bookAuthor = "";
                switch (selectedTitle) {
                    case "Life of Pi":
                        bookAuthor = "Yann Martel";
                        break;
                    case "Crime and Punishment":
                        bookAuthor = "Fyodor Dostoyevsky";
                        break;
                    case "The Karamazov Brothers":
                        bookAuthor = "Fyodor Dostoyevsky";
                        break;
                    case "War and Peace":
                        bookAuthor = "Lev Tolstoy";
                        break;
                    default:
                        break;
                }
                bookDescription.setText("This book was written by " + bookAuthor);
            }
        });
    }
    /*  lab 2 */

    /*
    App Life Cycle
    onCreate (Created)
    onStart (Visible)
    onResume (Active)
    onPause (Paused)
    onStop (Stopped)
    onDestroy (Destroyed)
    onRestart (Restarting)
     */

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("lifecycle","onStart invoked");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("lifecycle","onResume invoked");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("lifecycle","onPause invoked");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("lifecycle","onStop invoked");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("lifecycle","onDestroy invoked");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("lifecycle","onRestart invoked");
    }

    /*
   save instance state
   in bundle trb sa salvam descrierea din text
   on save instance state se apeleaza cand se distruge layoutul
   on restore instance state - luam din bundle informatiile si le punem din nou in textview

   new resource file in dir cu resurse si selectam sa fie menu si se va pune intr un folder separat menu
   pt contextuale si de optioni trb sa avem un inflator

    */

    @Override
    protected void onSaveInstanceState(Bundle onSaveState) {

        TextView bookDescription = (TextView) findViewById(R.id.bookDescription);
        description = bookDescription.getText().toString();
        onSaveState.putString("bookDescription", description);
        super.onSaveInstanceState(onSaveState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle onRestoreState) {
        super.onRestoreInstanceState(onRestoreState);
        TextView bookDescription = (TextView) findViewById(R.id.bookDescription);
        description = onRestoreState.getString("bookDescription");
        bookDescription.setText(description);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
}